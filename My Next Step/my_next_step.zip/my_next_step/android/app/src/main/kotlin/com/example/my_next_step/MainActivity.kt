package com.example.my_next_step

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
